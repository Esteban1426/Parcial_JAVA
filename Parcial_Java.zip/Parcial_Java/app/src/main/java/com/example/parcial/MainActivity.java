package com.example.parcial;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void añadirAmigo(View view){
        Intent intent = new Intent(this, SegundoActivity.class);
        TextView nombreTextView = findViewById(R.id.Nombre);
        TextView edadTextView = findViewById(R.id.Edad);
        TextView MateriaTextView = findViewById(R.id.Materia);
        int imagen = R.drawable.garfield;

        intent.putExtra("nombre", nombreTextView.getText().toString());
        intent.putExtra("edad", edadTextView.getText().toString());
        intent.putExtra("materia", MateriaTextView.getText().toString());
        intent.putExtra("imagen", imagen);

        startActivity(intent);
    }

    public void conocerMas(View view){
        Intent intent = new Intent(this, TercerActivity.class);
        TextView nombreTextView = findViewById(R.id.Nombre);
        TextView edadTextView = findViewById(R.id.Edad);
        TextView MateriaTextView = findViewById(R.id.Materia);
        int imagen = R.drawable.garfield;

        intent.putExtra("nombre", nombreTextView.getText().toString());
        intent.putExtra("edad", edadTextView.getText().toString());
        intent.putExtra("materia", MateriaTextView.getText().toString());
        intent.putExtra("imagen", imagen);

        startActivity(intent);
    }
}
